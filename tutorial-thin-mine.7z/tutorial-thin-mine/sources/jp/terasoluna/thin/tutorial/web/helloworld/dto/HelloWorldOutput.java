package jp.terasoluna.thin.tutorial.web.helloworld.dto;

public class HelloWorldOutput {
	
	private String helloWorld;

	public String getHelloWorld() {
		return helloWorld;
	}

	public void setHelloWorld(String helloWorld) {
		this.helloWorld = helloWorld;
	}

}
